<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Laporan</title>
    <link rel="stylesheet" href="assets/css/invoice.css" media="all" />
    <?php
    require 'controller/koneksi.php';
    
    ?>
  </head>
  <body>
    <header class="clearfix">
      <div id="logo">
        <img src="img/logo.png">
      </div>
      <h1>LAPORAN</h1>
      <div id="company" class="clearfix">
        <div>Bengkel Alfian Variasi</div>
        <div>Btp Blok A No.112</div>
        <div>(602) 519-0450</div>
        <div><a href="#">alfianvariasi@gmail.com</a></div>
      </div>
      <div id="project">
        <div><span>TENTANG</span> Laporan barang keluar</div>
      </div>
    </header>
    <main>
      <table>
        <thead>
          <tr>
            <th>NO</th>
            <th>KARYAWAN</th>
            <th>BARANG</th>
            <th>MEREK</th>
            <th>TYPE</th>
            <th>TAHUN RILIS</th>
            <th>JUMLAH BARANG</th>
          </tr>
        </thead>
        <tbody>
            <?php
            $sql = mysqli_query($koneksi,"SELECT * FROM data_barang_keluar join data_barang join data_type join data_merek join data_admin on data_barang.id_type = data_type.id_type and data_barang.id_merek = data_merek.id_merek and data_barang_keluar.id_barang = data_barang.id_barang  and data_admin.id_admin = data_barang_keluar.id_admin");
            $i = 1;
            while ($r = mysqli_fetch_array($sql)) {
            ?>
          <tr>
            <td><?=$i++;?></td>
            <td><?=$r['nama_admin'];?></td>
            <td><?=$r['nama_barang'];?></td>
            <td><?=$r['nama_merek'];?></td>
            <td><?=$r['nama_type'];?></td>
            <td><?=$r['tahun_rilis'];?></td>
            <td><?=$r['jumlah_keluar'];?></td>
          </tr>
         <?php
            }
         ?>
        </tbody>
      </table>
    </main>
    <script>
        window.print();
    </script>
  </body>
</html>