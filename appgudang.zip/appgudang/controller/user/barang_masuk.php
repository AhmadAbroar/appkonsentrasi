<?php 
require '../koneksi.php';
$barang = $_POST['id_barang'];
$tampil=mysqli_query($koneksi,"SELECT * FROM data_barang join data_type join data_merek on id_barang='$barang' and data_type.id_type = data_barang.id_type and data_merek.id_merek = data_barang.id_merek;");
$jml=mysqli_num_rows($tampil);
 
if($jml > 0){    
    while($r=mysqli_fetch_array($tampil)){
        ?>
        <label class="form-label">Merek</label>
        <input class="form-control" type="text" value="<?=$r['nama_merek'];?>" disabled>
        <label class="form-label">Type</label>
        <input class="form-control" type="text" value="<?=$r['nama_type'];?>" disabled>
        <label class="form-label">Stok Gudang</label>
        <input class="form-control" type="text" value="<?=$r['stok_barang'];?>" disabled>
        <?php        
    }
}
 
?>