<?php

require 'koneksi.php';

$pilih = $_POST['pilih'];
switch ($pilih) {
    case 1:
        $nama = $_POST['nama'];
        $alamat = $_POST['alamat'];
        $telp = $_POST['telp'];

        $sql = "INSERT into data_distributor values ('','$nama','$alamat','$telp')";
        if (mysqli_query($koneksi, $sql)) {
            exit('sukses');
        }

        break;
    case 2:
        $nama = $_POST['nama'];
        $alamat = $_POST['alamat'];
        $telp = $_POST['telp'];
        $id = $_POST['id'];

        $sql = "UPDATE data_distributor set nama_dist='$nama', alamat_dist='$alamat', telp='$telp' where id_dist ='$id'";
        if (mysqli_query($koneksi, $sql)) {
            exit('sukses');
        }

        break;
    case 3:
        $id = $_POST['id'];

        $sql = "DELETE from data_distributor where id_dist = '$id'";
        if (mysqli_query($koneksi, $sql)) {
            exit('sukses');
        }
        break;
}
