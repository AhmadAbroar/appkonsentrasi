<?php

require 'koneksi.php';

$pilih = $_POST['pilih'];
switch ($pilih) {
    case 1:
        $nama = $_POST['nama'];
        $username = $_POST['username'];
        $pass = $_POST['pass'];
        $level = $_POST['level'];

        //cek user
        $sequel = mysqli_query($koneksi,"SELECT * FROM data_admin where username_admin='$username'");
        $cek = mysqli_fetch_array($sequel);
        if($cek>0){
            exit('gagal');
        }else{
            $sql = "INSERT INTO data_admin VALUES ('','$nama','$username','$pass','$level')";
            if (mysqli_query($koneksi, $sql)) {
                exit('sukses');
            }
        }
        break;
    case 2:
        $nama = $_POST['nama'];
        $username = $_POST['username'];
        $pass = $_POST['pass'];
        $level = $_POST['level'];
        $id = $_POST['id'];

        //cek user
        $sequel = mysqli_query($koneksi,"SELECT * FROM data_admin where username_admin='$username'");
        $cek = mysqli_fetch_array($sequel);
        if($cek>0){
            exit('gagal');
        }else{
            $sql = "UPDATE data_admin set nama_admin='$nama', username_admin='$username', password_admin='$pass', level_admin='$level' where id_admin ='$id'";
            if (mysqli_query($koneksi, $sql)) {
                exit('sukses');
            }
        }
        

        break;
    case 3:
        $id = $_POST['id'];

        $sql = "DELETE from data_admin where id_admin = '$id'";
        if (mysqli_query($koneksi, $sql)) {
            exit('sukses');
        }
        break;
}
