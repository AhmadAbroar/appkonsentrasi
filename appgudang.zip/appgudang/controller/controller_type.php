<?php

require 'koneksi.php';

$pilih = $_POST['pilih'];
switch($pilih){
    case 1:
        $merek = $_POST['merek'];
        $type = $_POST['type'];
        $tgl = $_POST['tgl'];
        $cek = mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM data_type where nama_type = '$type' and tahun_rilis='$tgl'"));
        if($cek>0){
            exit('gagal');
        }else{
            $sql = "INSERT into data_type values ('','$merek','$type','$tgl')";
            if(mysqli_query($koneksi,$sql)){
                exit('sukses');
            }
        }
        break;
    case 2:
        $merek = $_POST['merek'];
        $type = $_POST['type'];
        $tgl = $_POST['tgl'];
        $id = $_POST['id'];
        
        $cek = mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM data_type where nama_type= '$type' and tahun_rilis='$tgl'"));
        if($cek>0){
            exit('gagal');
        }else{
            $sql = "UPDATE data_type set id_merek = '$merek', nama_type ='$type', tahun_rilis = '$tgl' where id_type='$id'";
            if(mysqli_query($koneksi,$sql)){
                exit('sukses');
            }
        }
        break;
    case 3:
        $id = $_POST['id'];
        $sql = "DELETE from data_type where id_type= '$id'";
        if(mysqli_query($koneksi,$sql)){
            exit('sukses');
        }
        break;
}