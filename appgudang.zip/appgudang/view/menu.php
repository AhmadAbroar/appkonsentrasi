<ul aria-expanded="false">
    <li><a href="index.php">Dashboard</a></li>
    <li><a href="data_barang.php">Data Barang</a></li>
    <li><a href="data_merek.php">Data Merek</a></li>
    <li><a href="data_type.php">Data Type</a></li>
    <li><a href="data_dist.php">Data Distributor</a></li>
    <li><a href="data_user.php">Data User</a></li>
</ul>