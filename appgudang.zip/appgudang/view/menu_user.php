<ul aria-expanded="false">
    <li><a href="index.php">Dashboard</a></li>
    <li><a href="data_barang_masuk.php">Data Barang Masuk</a></li>
    <li><a href="data_barang_keluar.php">Data Barang Keluar</a></li>
</ul>