  <!--**********************************
        Scripts
    ***********************************-->
        <!-- Required vendors -->
        <script src="assets/vendor/global/global.min.js"></script>
        <script src="assets/vendor/chart.js/Chart.bundle.min.js"></script>
        <!-- Apex Chart -->
        <script src="assets/vendor/apexchart/apexchart.js"></script>

        <!-- Datatable -->
        <script src="assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
        <script src="assets/js/plugins-init/datatables.init.js"></script>

        <script src="assets/vendor/jquery-nice-select/js/jquery.nice-select.min.js"></script>

        <script src="assets/js/custom.min.js"></script>
        <script src="assets/js/dlabnav-init.js"></script>
        <script src="assets/js/demo.js"></script>
        <script src="assets/js/styleSwitcher.js"></script>


        <!-- sweetalert -->
        <link rel="stylesheet" href="assets/node_modules/sweetalert2/dist/sweetalert2.min.css">
        <script src="assets/node_modules/sweetalert2/dist/sweetalert2.min.js"></script>